<?php
// Data from session
session_start();
$teamName = NULL;
if (isset($_SESSION['teamName'])) $teamName = $_SESSION['teamName'];

// Check
if ($teamName == NULL ) header("Location: logout.php");

?>

<!DOCTYPE html>
<html>
	<!-- Head -->
	<head>
		<!-- CSS files -->
		<link rel='stylesheet' type='text/css' href='./css/web.css' media='screen' />
		<link rel='stylesheet' type='text/css' href='./css/02_fonts.css' media='screen' />
		<link rel='stylesheet' type='text/css' href='./css/03_icons.css' media='screen' />
		<link rel='stylesheet' type='text/css' href='./css/webDesign4.css' media='screen' />
		<link rel='stylesheet' type='text/css' href='./css/main.css' media='screen' />

		<!-- JS files -->
		<script type='text/javascript' src='./js/jquery-3.7.0.min.js'></script>
		<script type='text/javascript' src='./js/jquery-ui.min.js'></script>
		<!-- <script flag='H7mL_I5_N0t3_53cUR3!!!'></script> -->
		<script type='text/javascript' src='./js/web.js'></script>
		<script type='text/javascript' src='./js/ajxAddData.js'></script>
		<script type='text/javascript' src='./js/ajxGetHtmlDatas.js'></script>

		<!-- UTF8 encoding -->
		<meta charset='UTF-8'>

		<!-- Prevent from zooming -->
		<!-- <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=0,  shrink-to-fit=no"> -->

		<!-- Icon -->
		<link rel='icon' type='image/png' href='./design/favicon.png' />

		<!-- Title -->
		<title>ENIGMAHACK</title>
	</head>



	<!-- Body -->
	<body>
		<!-- Wrapper -->
		<div class='wrapper'>

			<section>
				<h1 class='typewriter'>ENIGMAHACK</h1>
			</section>

			<section>
				<h2>Ajout</h2>
				<ul>
					<li class='add'>
							<input type='text' name='flag' placeholder='flag' minlength='3' maxlength='100' required/>
							<input type='text' name='idChallenge' placeholder='idChallenge' minlength='0' maxlength='100' required/>
							<button type="button" class = 'add' name='add'>Ajouter</button>
					</li>
				</ul>

			</section>

			<section>
				<h2>Vos données</h2>
				<ul>
					<li class='view'>
					</li>
				</ul>
			</section>

			<section>
				<ul>
					<li><a href='logout.php'>Déconnexion</a></li>
				</ul>
			</section>

		</div>
	</body>
</html>
